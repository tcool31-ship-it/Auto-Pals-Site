
async function loadInventory(){
  const res = await fetch('/data/inventory.json');
  const data = await res.json();
  return data.vehicles;
}
function money(n){ return n.toLocaleString('en-US', {style:'currency', currency:'USD', maximumFractionDigits:0}); }

function getParam(key){
  const url = new URL(window.location.href);
  return url.searchParams.get(key);
}

async function renderVehicle(){
  const container = document.getElementById('vehicle-detail');
  const inv = await loadInventory();
  const id = getParam('id');
  const v = inv.find(x => String(x.id) === String(id)) || inv[0];
  document.querySelector('#vehicle-title h1').textContent = `${v.year} ${v.make} ${v.model}`;
  document.querySelector('#vehicle-sub').textContent = `${money(v.price)} • ${v.mileage.toLocaleString()} mi • ${v.transmission} • ${v.drivetrain}`;

  container.innerHTML = `
    <div>
      <div class="gallery">
        ${v.images.map(src => `<img src="${src}" alt="${v.year} ${v.make} ${v.model}">`).join('')}
      </div>
      <div class="specs">
        <div><span>Price</span><strong>${money(v.price)}</strong></div>
        <div><span>Mileage</span><strong>${v.mileage.toLocaleString()} mi</strong></div>
        <div><span>Transmission</span><strong>${v.transmission}</strong></div>
        <div><span>Drivetrain</span><strong>${v.drivetrain}</strong></div>
        <div><span>VIN</span><strong>${v.vin}</strong></div>
        <div><span>Exterior</span><strong>${v.color}</strong></div>
        <div><span>Interior</span><strong>${v.interior||'—'}</strong></div>
        <div><span>Fuel</span><strong>${v.fuel}</strong></div>
      </div>
    </div>
    <aside class="card">
      <h3>${money(v.price)}</h3>
      <p>${v.year} ${v.make} ${v.model}</p>
      <ul class="nice-list">
        <li>${v.mileage.toLocaleString()} miles</li>
        <li>${v.transmission} • ${v.drivetrain}</li>
        <li>${v.type} • ${v.fuel}</li>
      </ul>
      <a class="btn primary" href="tel:+18034671416">Call 803‑467‑1416</a>
      <a class="btn" href="mailto:info@autopalsllc.com?subject=Inquiry: ${encodeURIComponent(v.year+' '+v.make+' '+v.model)}">Email Us</a>
      <hr style="border:none;border-top:1px solid #ececf2;margin:16px 0">
      <p class="muted-text">We partner with local and national lenders. Apply on our <a href="/financing.html">Financing</a> page.</p>
      <p class="muted-text">Nationwide shipping available. Request a quote.</p>
    </aside>
  `;
}

document.addEventListener('DOMContentLoaded', renderVehicle);
