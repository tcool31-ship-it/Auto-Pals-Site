
async function loadInventory(){
  const res = await fetch('/data/inventory.json');
  const data = await res.json();
  return data.vehicles;
}

function money(n){ return n.toLocaleString('en-US', {style:'currency', currency:'USD', maximumFractionDigits:0}); }

function vehicleCard(v){
  const url = `/vehicle.html?id=${encodeURIComponent(v.id)}`;
  return `
  <article class="vehicle-card">
    <a href="${url}"><img class="thumb" src="${v.images[0]}" alt="${v.year} ${v.make} ${v.model}"></a>
    <div class="body">
      <a href="${url}"><strong>${v.year} ${v.make} ${v.model}</strong></a>
      <div class="meta">${v.transmission} • ${v.drivetrain} • ${v.color}</div>
      <div class="badges">
        <span class="badge">${v.mileage.toLocaleString()} mi</span>
        <span class="badge">${v.type}</span>
        <span class="badge">${v.fuel}</span>
      </div>
      <div class="price">${money(v.price)}</div>
    </div>
  </article>`;
}

async function renderFeatured(selector, count=3){
  const el = document.querySelector(selector);
  if(!el) return;
  const inv = await loadInventory();
  const featured = inv.filter(v => v.featured).slice(0,count);
  el.innerHTML = featured.map(vehicleCard).join('');
}

function applyFilters(vehicles){
  const q = document.getElementById('search').value.trim().toLowerCase();
  const t = document.getElementById('type').value;
  const yMin = parseInt(document.getElementById('yearMin').value || '0', 10);
  const yMax = parseInt(document.getElementById('yearMax').value || '3000', 10);
  const pMin = parseInt(document.getElementById('priceMin').value || '0', 10);
  const pMax = parseInt(document.getElementById('priceMax').value || '9999999', 10);
  const mMax = parseInt(document.getElementById('mileageMax').value || '9999999', 10);
  return vehicles.filter(v => {
    const qmatch = !q || (`${v.year} ${v.make} ${v.model} ${v.notes||''}`.toLowerCase().includes(q));
    const tmatch = !t || v.type === t;
    return qmatch && tmatch && v.year >= yMin && v.year <= yMax && v.price >= pMin && v.price <= pMax && v.mileage <= mMax;
  });
}

function sortVehicles(list){
  const sort = document.getElementById('sort').value;
  const by = {
    'featured': (a,b)=> (b.featured?1:0) - (a.featured?1:0),
    'price-asc': (a,b)=> a.price - b.price,
    'price-desc': (a,b)=> b.price - a.price,
    'year-desc': (a,b)=> b.year - a.year,
    'year-asc': (a,b)=> a.year - b.year,
    'mileage-asc': (a,b)=> a.mileage - b.mileage,
    'mileage-desc': (a,b)=> b.mileage - a.mileage,
  }[sort];
  return list.slice().sort(by);
}

function paginate(list, page, perPage){
  const total = Math.ceil(list.length / perPage);
  const start = (page-1)*perPage;
  return { total, items: list.slice(start, start+perPage) };
}

async function renderInventory(selector, opts){
  const grid = document.querySelector(selector);
  const countEl = document.querySelector(opts.countEl);
  const paginationEl = document.querySelector(opts.paginationEl);
  const inventory = await loadInventory();

  const inputs = ['search','type','yearMin','yearMax','priceMin','priceMax','mileageMax','sort'].map(id=>document.getElementById(id));
  inputs.forEach(i => i && i.addEventListener('input', () => draw(1)));
  document.getElementById('clearFilters').addEventListener('click', () => {
    inputs.forEach(i => { if(i.tagName==='SELECT') i.selectedIndex=0; else i.value=''; });
    draw(1);
  });

  function draw(page=1){
    const filtered = applyFilters(inventory);
    const sorted = sortVehicles(filtered);
    const { total, items } = paginate(sorted, page, 9);
    if (countEl) countEl.textContent = `${filtered.length} vehicle${filtered.length===1?'':'s'} found`;
    grid.innerHTML = items.map(vehicleCard).join('');
    paginationEl.innerHTML = '';
    if(total>1){
      for(let p=1; p<=total; p++){
        const btn = document.createElement('button');
        btn.textContent = p;
        if(p===page) btn.style.background = '#eef5ff';
        btn.addEventListener('click', ()=> draw(p));
        paginationEl.appendChild(btn);
      }
    }
  }

  draw(1);
}

